 
 
    <div class="footer">
        <div class="wrapper">
            <p class="text-center">
                Địa chỉ: Tầng 4-5-6, Tòa nhà Capital Place, số 29 đường Liễu Giai, Phường Ngọc Khánh, Quận Ba Đình, Thành phố Hà Nội, Việt Nam.
                <a href="#" style="text-decoration: none; color: #ff6348; font-weight: 500;">Developed By Hoang Nguyet Ha</a>
            </p>
        </div>
    </div>

</body>

</html>